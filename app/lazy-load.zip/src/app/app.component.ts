import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'app';
  showComponent: Subject<boolean> = new Subject<boolean>();
  //@ts-ignore
  @ViewChild('container', { read: ViewContainerRef }) container: ViewContainerRef = null;
  showOrHide = false

  ngOnInit(): void {
    // this.showComponent.subscribe(value=>{
    //   this.title=`${value}`
    //   if(value){
    //     import('./components/test/test.component').then(m => {
    //       this.container.createComponent(m.TestComponent);

    //     });
    //   }else{
    //     this.container.clear()
    //   }

    // })
  }


  toggleShow() {
    this.showOrHide = !this.showOrHide;

    this.showOrHide ?
      import('./components/test/test.component').then(m => {
        this.container.createComponent(m.TestComponent);

      }) :
      this.container.clear();

  }


}
