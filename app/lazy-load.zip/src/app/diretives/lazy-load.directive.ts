import { Directive, Input, ViewContainerRef, ComponentFactoryResolver, OnInit } from '@angular/core';

@Directive({
  selector: '[lazyLoad]',
})
export class LazyLoadDirective implements OnInit {

  @Input('lazyLoad') path: string="";

  constructor(
    private container: ViewContainerRef,
    private cfr: ComponentFactoryResolver
  ) { }

  ngOnInit(): void {
    import(`${this.path}`).then(m => {
      const componentFactory = this.cfr.resolveComponentFactory(m.default);
      this.container.createComponent(componentFactory);
    });
  }

}
